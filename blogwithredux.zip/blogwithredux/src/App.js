import "./App.css";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from 'react-redux';
import { fetchBlogDatta} from './redux/action/action';
const App = ( ) => {
  const dispatch = useDispatch();
  const {blogs , loading , error } = useSelector((state) => state.blog);
  useEffect(() =>{
    dispatch(fetchBlogDatta());
  },[dispatch]);
  if(loading){
    return <div>loading...</div>
  }
  if(error){
    return <div> Error:{error}</div>
  }
  
  return (
      <div className="blog_parent">
     {
  blogs.map((blog) => (
    <div className="blogcard_wrap" key={blog.id}>
      <div className="image_container">
        <img
          src={blog.promotion_image_url}
          alt="firstblog"
          className="blogimage"
        />
      </div>
      <div className="card_content">
        <h5 className="heading">{blog.title}</h5>
        <p className="para">{blog.subtitle}</p>
      </div>
    </div>
  ))
}
</div>           
  )      
}
export default App;
