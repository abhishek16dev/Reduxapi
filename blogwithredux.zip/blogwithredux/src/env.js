export const BASE_HOST = "https://api-dev.rupyz.com/v1";
