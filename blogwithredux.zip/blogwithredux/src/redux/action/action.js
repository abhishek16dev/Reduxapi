import axios from 'axios';
import {BASE_HOST} from '../../env';
export const GETBLOGREQUEST = 'GETBLOGREQUEST' ;
export const GETBLOGSUCCESS = 'GETBLOGSUCCESS' ;
export const GETBLOGFAILED  = 'GETBLOGFAILED'  ;
const url = `${BASE_HOST}/blog/public/?page_no=1`;


export const fetchBlogRequest = () => ({
    type: GETBLOGREQUEST,
  });
  
  export const fetchBlogSuccess = (data) => ({
    type: GETBLOGSUCCESS,
    payload: data,
  });
  
  export const fetchBlogFailure = (error) => ({
    type: GETBLOGFAILED,
    payload: error,
  });
  

  

export const  fetchBlogDatta = () =>{
return (dispatch) => {
    dispatch(fetchBlogRequest()) ;
  axios.get(url)
.then((res) => {

   switch(res.status){

    case 200:
        dispatch(fetchBlogSuccess(res.data.data) );
        break;
   default:
    dispatch(fetchBlogFailure('an eeor occured')
    );

    break;

    }
})
.catch((error) =>{
    dispatch(fetchBlogFailure(error.message));
}) ;
};
};
