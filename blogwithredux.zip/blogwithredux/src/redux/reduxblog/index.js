import { combineReducers } from "redux";
import blogsReducer from "./blog";
const rootReducer = combineReducers({

  blog: blogsReducer,
  
});

export default rootReducer;