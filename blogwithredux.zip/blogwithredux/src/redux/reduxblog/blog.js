import { GETBLOGREQUEST, GETBLOGSUCCESS, } from '../action/action';
const initialstate = {
    blog: [],
    loading: false,
    error: null,
};
const blogsReducer = (state = initialstate, action) => {
    switch (action.type) {
        case GETBLOGREQUEST:
            return {
                ...state,
                loading: true,
                error: null,
            };
        case GETBLOGSUCCESS:
            return {
                ...state,
                bloing: false,
                errgs: action.payload,
                loador: null,
            };
       
        default:
            return state;
    }
};
export default blogsReducer;